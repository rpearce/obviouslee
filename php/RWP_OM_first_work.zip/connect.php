<?php include("includes/head.php"); ?>
<body style="background:url('images/bg-connect.gif') no-repeat -900px 0px">
<?php include("includes/header.php"); ?>
		
<div class="content" id="connect">
	<div class="tagline">S&rsquo;up?</div>
	<div class="features">
	</div>
</div>
		
<?php include("includes/footer.php"); ?>