<?php include("includes/head.php"); ?>
<body style="background:url('images/bg-home.gif') no-repeat -400px 0px">
<?php include("includes/header.php"); ?>
		
<div class="content" id="home">
	<div class="tagline">Game. <span style="color:#2b8fb0;">OM.</span></div>
	<div class="features">
		<div class="feature" id="feature1">
			<h1>Our Work</h1>
		</div>
		<div class="feature" id="feature2">
			<h1>Our Crew</h1>
		</div>
		<div class="feature" id="feature3">
			<h1>Our Capabilities</h1>
		</div>
		<div class="clear"></div>
	</div>
</div>
		
<?php include("includes/footer.php"); ?>