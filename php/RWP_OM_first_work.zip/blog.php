<?php include("includes/head.php"); ?>
<body>
<?php include("includes/header.php"); ?>
		
<div class="content" id="home">
	<div class="tagline"><img src="images/home-tagline.png" /></div>
	<div class="features">
		<div class="feature" id="feature1"><img src="images/feature-1.jpg" alt="2012 PGA Championship" /></div>
		<div class="feature" id="feature2"><img src="images/feature-2.jpg" alt="Production Design Associates" /></div>
		<div class="feature" id="feature3"><img src="images/feature-3.jpg" alt="Bottles" /></div>
		<div class="clear"></div>
	</div>
</div>
		
<?php include("includes/footer.php"); ?>