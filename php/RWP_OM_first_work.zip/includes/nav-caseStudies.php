<div class="csMenu" style="display:none;">
	<ul>
		<li><a href="" class="arrow"><img src="images/caseStudy-arrow-left.gif" class="arrow" /></a></li>
		<li><a href="" class="pga">2012 PGA Championship</a></li>
		<li><a href="" class="fcc">Family Circle Cup, Tennis Center + Concerts</a></li>
		<li><a href="" class="ffv">Firefly Vodka</a></li>
		<li><a href="" class="tsi">Town of Seabrook Island</a></li>
		<li><a href="" class="btl">Bottles</a></li>
		<li><a href="" class="arrow"><img src="images/caseStudy-arrow-right.gif" class="arrow" /></a></li>
	</ul>
</div>


<div class="csMenu">
	<a href=""><img src="images/caseStudy-arrow-left.gif" class="arrow" /></a>
	<div class="scroll">
		<ul>
			<li><a href="" class="pga">2012 PGA Championship</a></li>
			<li><a href="" class="fcc">Family Circle Cup, Tennis Center + Concerts</a></li>
			<li><a href="" class="ffv">Firefly Vodka</a></li>
			<li><a href="" class="tsi">Town of Seabrook Island</a></li>
			<li><a href="" class="btl">Bottles</a></li>
			<div class="clear"></div>
		</ul>
	</div>
	<a href=""><img src="images/caseStudy-arrow-right.gif" class="arrow" /></a>
</div>
