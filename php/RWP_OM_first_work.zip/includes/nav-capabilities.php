<ul class="nav">
	<li class="advertising"><a href="#advertising">Advertising</a></li>
	<li class="brandStrategy"><a href="#brandStrategy">Brand Strategy</a></li>
	<li class="creative"><a href="#creative">Creative</a></li>
	<li class="interactive"><a href="#interactive">Interactive</a></li>
	<li class="publicRelations"><a href="#publicRelations">Public Relations</a></li>
</ul>