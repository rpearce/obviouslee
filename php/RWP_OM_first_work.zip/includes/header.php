<div id="container">
	<div id="header">
		<div class="logo"><a href="index.php"><img src="images/header-logo.png" alt="Home" title="Home" /></a></div>
		<div class="menu">
			<ul>
				<li><a href="the-om-way.php" title="The OM Way">The OM Way</a></li>
				<li><a href="crew.php" title="Crew">Crew</a></li>
				<li><a href="work.php" title="Work">Work</a></li>
				<li><a href="capabilities.php" title="Capabilities">Capabilities</a></li>
				<li><a href="connect.php" title="Connect">Connect</a></li>
				<li><a href="/blog/" title="Blog">Blog</a></li>
			</ul>
		</div>
	</div>