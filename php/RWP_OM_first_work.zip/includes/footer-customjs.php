		<div id="footer">
			<div class="logo"></div>
			<div class="address">501 Wando Park Boulevard, Suite 200 &nbsp;&nbsp;|&nbsp;&nbsp; Mt. Pleasant, SC 29464 &nbsp;&nbsp;|&nbsp;&nbsp; 843.972.0712<br /><a href="mailto:whattooksolong@obviouslee.com">Whattooksolong@obviouslee.com</a></div>
			<div class="social">
				<div class="flickr"><a href="http://www.flickr.com/photos/obviousleemarketing/" target="_blank"><img src="images/footer-social-flickr.png" alt="Flickr" title="Flickr" /></a></div>
				<div class="twitter"><a href="http://twitter.com/#!/obviouslee" target="_blank"><img src="images/footer-social-twitter.png" alt="Twitter" title="Twitter" /></a></div>
				<div class="facebook"><a href="http://www.facebook.com/obviousleemarketing?ref=ts" target="_blank"><img src="images/footer-social-facebook.png" alt="Facebook" title="Facebook" /></a></div>
				<div class="vimeo"><a href="http://www.youtube.com/user/obviouslee3" target="_blank"><img src="images/footer-social-vimeo.png" alt="Vimeo" title="Vimeo" /></a></div>
			</div>
		</div>
	</div><!--container-->
	<!-- Inserted by rwp -->
  <script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
  <script src="js/jquery-scrollTo-custom.min.js"></script>
  <script src="js/jquery-localscroll.min.js"></script>
  <script src="js/app.js"></script>
  <!-- End Insert -->
</body>
</html>
